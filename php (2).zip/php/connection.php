<?php 
//  se crean la variables a la Conexion a la base de datos
$servername = "localhost";
$username = "root";
$password = "motita123";
$database = "login_register";

// se crea la conexion  

$conn = new mysqli($servername, $username, $password, $database);

?>

