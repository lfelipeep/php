



<html>
  
    <footer>
        <p> 2025 &copy;  Mi Sitio Web. Todos los derechos reservados. </p>
    </footer>
</html>