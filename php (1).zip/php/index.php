
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login / singup</title>

<!-- se referencia archivos externos que se utilizan en la pagina -->
    <link rel= "stylesheet" href="css/style.css">
</head>
<body>

        <h1> Bienvenido, por favor ingrese o registrese en la pagina </h1>

        <div id="enlaces"> 
             <br> <a href = "login.php"> accede aqui </a> </br>
             <br> <a href = "singup.php"> registrese aqui </a> </br>
        </div>



</body>


    <?php include './includes/footer.php'; ?>
</html>